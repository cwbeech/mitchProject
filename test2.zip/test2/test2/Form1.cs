﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using static System.Windows.Forms.VisualStyles.VisualStyleElement.Menu;

namespace test2
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
            Fill();
        }

        public void Fill()
        {
            //int[,] numbers = { { 1, 4, 2 }, { 3, 6, 8 } };

            int[,] numbers = new int[40, 100];
            Random random = new Random();
            for (int i = 0; i < numbers.GetLength(0); i++)
            {
                for (int j = 0; j < numbers.GetLength(1); j++)
                {
                    numbers[i, j] = random.Next(1, 4); // Generates random numbers between 1 and 3
                }
            }

            for (int i = 0; i < numbers.GetLength(0); i++)
            {
                FlowLayoutPanel p = new FlowLayoutPanel();
                p.AutoScroll = true;
                p.FlowDirection = FlowDirection.LeftToRight;
                p.WrapContents = false;
                p.AutoSize = true;
                p.Margin = new Padding(0);
                for (int j = 0; j < numbers.GetLength(1); j++)
                {
                    Label l = new Label();
                    l.Text = numbers[i, j].ToString();
                    l.Height = p.Height/7;
                    l.Width = p.Height/7;
                    l.Margin = new Padding(0);
                    l.TextAlign = ContentAlignment.MiddleCenter;
                    
                    //l.Font = new Font(FontFamily.GenericMonospace.ToString(), 16);
                    l.BorderStyle = BorderStyle.FixedSingle;

                    p.Controls.Add(l);
                }
                Painting.Controls.Add(p);
            }
        }
    }
}
